# Trava EHR — app Android

App com dois botões (TRAVAR e DESTRAVAR) que conversa com o ESP32 da trava pela rede Wi-Fi dela.

## Só instalar
Use o `TravaEHR.apk` entregue junto (não precisa compilar nada).

## Alterar no Android Studio
1. Android Studio > File > Open > esta pasta (`TravaEHR`).
2. Espere o Gradle sincronizar (ele baixa o que faltar; aceite instalar o Android SDK 34 se pedir).
3. Celular com "Depuração USB" ligada > botão Run.

Tudo está em `app/src/main/java/br/com/ehr/trava/MainActivity.java`:
- `IP_PADRAO` — endereço da trava (192.168.4.1)
- `montarTela()` — textos, cores e tamanho dos botões
- `requisitar()` — comunicação HTTP com o ESP32

## Assinatura
`app/trava-ehr.p12` (senha `trava-ehr`) é a chave que assina o app. Use sempre a mesma chave:
com outra, o Android só instala a versão nova depois de desinstalar a antiga.

## Comunicação com a trava
- `GET  /status`
- `POST /travar`     corpo `pin=1234`
- `POST /destravar`  corpo `pin=1234`

Resposta (JSON):
`{"ok":true,"estado":"TRAVADO","palhetas":["travada","travada","travada"],"msg":"Trava acionada"}`
