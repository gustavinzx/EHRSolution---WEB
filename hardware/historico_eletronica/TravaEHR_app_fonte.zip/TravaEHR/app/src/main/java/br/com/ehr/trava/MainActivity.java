package br.com.ehr.trava;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Trava EHR — controle da trava de abastecimento pelo Wi-Fi.
 *
 * O celular conecta na rede Wi-Fi criada pelo ESP32 da trava (ex.: TRAVA-EHR-01)
 * e o app conversa com ela em http://192.168.4.1:
 *   GET  /status                 estado atual
 *   POST /travar     pin=1234    trava as palhetas
 *   POST /destravar  pin=1234    libera as palhetas
 */
public class MainActivity extends Activity {

    private static final String IP_PADRAO = "192.168.4.1";

    private static final int COR_FUNDO      = 0xFFF3F4F6;
    private static final int COR_TEXTO      = 0xFF1D2126;
    private static final int COR_TEXTO_2    = 0xFF5B6270;
    private static final int COR_LINK       = 0xFF1E5AA8;
    private static final int COR_TRAVADO    = 0xFF2E7D32;
    private static final int COR_DESTRAVADO = 0xFFE65100;
    private static final int COR_ATENCAO    = 0xFFB26A00;
    private static final int COR_SEM_REDE   = 0xFF8A8F98;

    private SharedPreferences prefs;
    private TextView txtIcone, txtEstado, txtMsg, txtPalhetas, txtRodape;
    private Button btnTravar, btnDestravar, btnWifi, btnConfig;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean visivel = false;      // tela aberta
    private boolean ocupado = false;      // comando em andamento
    private boolean consultando = false;  // /status em andamento

    private final View.OnClickListener cliques = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == btnTravar || v == btnDestravar) {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                comando(v == btnTravar);
            } else if (v == btnConfig) {
                abrirConfiguracoes("Configurações");
            } else if (v == btnWifi) {
                abrirWifi();
            }
        }
    };

    /** Atualiza o estado da trava a cada 3 s enquanto a tela estiver aberta. */
    private final Runnable atualizador = new Runnable() {
        @Override
        public void run() {
            if (!visivel) return;
            if (!ocupado) consultarStatus();
            handler.postDelayed(this, 3000);
        }
    };

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("trava_ehr", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().setStatusBarColor(COR_FUNDO);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(montarTela());
        txtEstado.setText("Procurando a trava…");
        txtEstado.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        if (pin().isEmpty()) txtMsg.setText("Toque em Configurações e informe o PIN da trava.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        visivel = true;
        handler.removeCallbacks(atualizador);
        handler.post(atualizador);
    }

    @Override
    protected void onPause() {
        super.onPause();
        visivel = false;
        handler.removeCallbacks(atualizador);
    }

    // ------------------------------------------------------------------ tela

    private View montarTela() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(28), dp(24), dp(24));

        TextView titulo = texto("TRAVA EHR", 14, COR_TEXTO_2, true);
        titulo.setLetterSpacing(0.18f);
        col.addView(titulo);

        txtIcone = texto("🔒", 60, COR_TEXTO, false);
        txtIcone.setPadding(0, dp(30), 0, dp(4));
        txtIcone.setAlpha(0.35f);
        col.addView(txtIcone);

        txtEstado = texto("", 34, COR_SEM_REDE, true);
        col.addView(txtEstado);

        txtMsg = texto("", 16, COR_TEXTO_2, false);
        txtMsg.setPadding(0, dp(8), 0, 0);
        col.addView(txtMsg);

        txtPalhetas = texto("", 13, COR_TEXTO_2, false);
        txtPalhetas.setPadding(0, dp(6), 0, 0);
        col.addView(txtPalhetas);

        btnWifi = botaoTexto("Abrir configurações de Wi-Fi");
        btnWifi.setVisibility(View.GONE);
        btnWifi.setOnClickListener(cliques);
        col.addView(btnWifi);

        View espaco = new View(this);
        col.addView(espaco, new LinearLayout.LayoutParams(1, dp(28)));

        btnTravar = botao("TRAVAR", COR_TRAVADO);
        btnTravar.setOnClickListener(cliques);
        col.addView(btnTravar, parametrosBotao());

        btnDestravar = botao("DESTRAVAR", COR_DESTRAVADO);
        btnDestravar.setOnClickListener(cliques);
        col.addView(btnDestravar, parametrosBotao());

        btnConfig = botaoTexto("⚙  Configurações");
        btnConfig.setOnClickListener(cliques);
        LinearLayout.LayoutParams lpConfig = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpConfig.topMargin = dp(22);
        col.addView(btnConfig, lpConfig);

        txtRodape = texto("", 12, COR_SEM_REDE, false);
        col.addView(txtRodape);
        atualizarRodape();

        ScrollView rolagem = new ScrollView(this);
        rolagem.setFillViewport(true);
        rolagem.setBackgroundColor(COR_FUNDO);
        rolagem.setFitsSystemWindows(true);
        rolagem.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return rolagem;
    }

    private TextView texto(String s, int sp, int cor, boolean negrito) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(cor);
        t.setGravity(Gravity.CENTER);
        if (negrito) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button botao(String rotulo, int cor) {
        Button b = new Button(this);
        b.setText(rotulo);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setLetterSpacing(0.06f);
        GradientDrawable fundo = new GradientDrawable();
        fundo.setColor(cor);
        fundo.setCornerRadius(dp(18));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), fundo, null));
        b.setStateListAnimator(null);
        return b;
    }

    private Button botaoTexto(String rotulo) {
        Button b = new Button(this);
        b.setText(rotulo);
        b.setAllCaps(false);
        b.setTextColor(COR_LINK);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        GradientDrawable mascara = new GradientDrawable();
        mascara.setColor(Color.WHITE);
        mascara.setCornerRadius(dp(10));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x221E5AA8), null, mascara));
        b.setStateListAnimator(null);
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        return b;
    }

    private LinearLayout.LayoutParams parametrosBotao() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(88));
        lp.topMargin = dp(14);
        return lp;
    }

    private void habilitarBotoes(boolean sim) {
        btnTravar.setEnabled(sim);
        btnDestravar.setEnabled(sim);
        btnTravar.setAlpha(sim ? 1f : 0.45f);
        btnDestravar.setAlpha(sim ? 1f : 0.45f);
    }

    private void atualizarRodape() {
        txtRodape.setText("Trava em " + ip());
    }

    // ------------------------------------------------------------------ ações

    private void comando(final boolean travar) {
        if (ocupado) return;
        final String pin = pin();
        if (pin.isEmpty()) {
            abrirConfiguracoes("Informe o PIN da trava");
            return;
        }
        ocupado = true;
        habilitarBotoes(false);
        txtMsg.setTextColor(COR_TEXTO_2);
        txtMsg.setText(travar ? "Travando…" : "Destravando…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                String corpo = "pin=" + codificar(pin);
                final Resposta r = requisitar(travar ? "/travar" : "/destravar", corpo, 4000, 9000);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ocupado = false;
                        habilitarBotoes(true);
                        mostrar(r, true);
                    }
                });
            }
        }).start();
    }

    private void consultarStatus() {
        if (consultando) return;
        consultando = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Resposta r = requisitar("/status", null, 2500, 3500);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        consultando = false;
                        if (!ocupado) mostrar(r, false);
                    }
                });
            }
        }).start();
    }

    private void mostrar(Resposta r, boolean foiComando) {
        txtEstado.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        txtIcone.setAlpha(1f);

        if (!r.conectou) {
            txtIcone.setText("📶");
            txtIcone.setAlpha(0.35f);
            txtEstado.setText("SEM CONEXÃO");
            txtEstado.setTextColor(COR_SEM_REDE);
            txtMsg.setTextColor(COR_TEXTO_2);
            txtMsg.setText(foiComando
                    ? "O comando não chegou à trava. Confira se o celular está na rede Wi-Fi da trava."
                    : "Conecte o celular à rede Wi-Fi da trava (ex.: TRAVA-EHR-01).");
            txtPalhetas.setText("");
            btnWifi.setVisibility(View.VISIBLE);
            return;
        }
        btnWifi.setVisibility(View.GONE);

        int cor;
        String icone;
        if ("TRAVADO".equals(r.estado)) {
            cor = COR_TRAVADO;
            icone = "🔒";
        } else if ("DESTRAVADO".equals(r.estado)) {
            cor = COR_DESTRAVADO;
            icone = "🔓";
        } else {
            cor = COR_ATENCAO;
            icone = "⚠️";
        }
        txtIcone.setText(icone);
        txtEstado.setText(r.estado.isEmpty() ? "?" : r.estado);
        txtEstado.setTextColor(cor);

        String msg = r.msg;
        if (r.codigo == 401) msg += " — confira em Configurações";
        boolean alerta = !r.ok || "INDEFINIDO".equals(r.estado);
        txtMsg.setText(msg);
        txtMsg.setTextColor(alerta ? COR_ATENCAO : COR_TEXTO_2);

        if (r.palhetas != null && r.palhetas.length > 0) {
            StringBuilder sb = new StringBuilder("Palhetas   ");
            for (int i = 0; i < r.palhetas.length; i++) {
                if (i > 0) sb.append("  ·  ");
                sb.append(i + 1).append(": ").append(r.palhetas[i]);
            }
            txtPalhetas.setText(sb.toString());
        } else {
            txtPalhetas.setText("");
        }
    }

    private void abrirConfiguracoes(String titulo) {
        LinearLayout caixa = new LinearLayout(this);
        caixa.setOrientation(LinearLayout.VERTICAL);
        caixa.setPadding(dp(24), dp(12), dp(24), 0);

        final EditText edIp = new EditText(this);
        edIp.setSingleLine(true);
        edIp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        edIp.setText(ip());

        final EditText edPin = new EditText(this);
        edPin.setSingleLine(true);
        edPin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        edPin.setText(pin());

        caixa.addView(rotulo("Endereço da trava"));
        caixa.addView(edIp);
        caixa.addView(rotulo("PIN da trava"));
        caixa.addView(edPin);

        new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setView(caixa)
                .setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int qual) {
                        String novoIp = edIp.getText().toString().trim()
                                .replaceFirst("^https?://", "").replaceAll("/+$", "");
                        if (novoIp.isEmpty()) novoIp = IP_PADRAO;
                        prefs.edit()
                                .putString("ip", novoIp)
                                .putString("pin", edPin.getText().toString().trim())
                                .apply();
                        atualizarRodape();
                        consultarStatus();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
        edPin.requestFocus();
    }

    private TextView rotulo(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTextColor(COR_TEXTO_2);
        t.setPadding(0, dp(12), 0, 0);
        return t;
    }

    private void abrirWifi() {
        Intent i = Build.VERSION.SDK_INT >= 29
                ? new Intent(Settings.Panel.ACTION_WIFI)
                : new Intent(Settings.ACTION_WIFI_SETTINGS);
        try {
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        }
    }

    // ------------------------------------------------------------------ rede

    private static class Resposta {
        boolean conectou = false;
        int codigo = 0;
        boolean ok = false;
        String estado = "";
        String msg = "";
        String[] palhetas;
    }

    /** Faz a requisição HTTP. corpo == null -> GET; senão POST de formulário. */
    private Resposta requisitar(String caminho, String corpo, int tempoConexao, int tempoLeitura) {
        Resposta r = new Resposta();
        HttpURLConnection con = null;
        try {
            URL url = new URL("http://" + ip() + caminho);
            con = abrirConexao(url);
            con.setConnectTimeout(tempoConexao);
            con.setReadTimeout(tempoLeitura);
            con.setUseCaches(false);
            if (corpo != null) {
                byte[] dados = corpo.getBytes("UTF-8");
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                con.setFixedLengthStreamingMode(dados.length);
                OutputStream saida = con.getOutputStream();
                saida.write(dados);
                saida.close();
            }
            r.codigo = con.getResponseCode();
            InputStream entrada = r.codigo >= 400 ? con.getErrorStream() : con.getInputStream();
            String texto = entrada != null ? lerTudo(entrada) : "";
            r.conectou = true;

            JSONObject j = new JSONObject(texto);
            r.ok = j.optBoolean("ok", false);
            r.estado = j.optString("estado", "");
            r.msg = j.optString("msg", "");
            JSONArray p = j.optJSONArray("palhetas");
            if (p != null) {
                r.palhetas = new String[p.length()];
                for (int i = 0; i < p.length(); i++) r.palhetas[i] = p.optString(i, "?");
            }
        } catch (JSONException e) {
            r.ok = false;
            r.msg = "Resposta inesperada da trava (código " + r.codigo + ")";
        } catch (Exception e) {
            r.conectou = false;
        } finally {
            if (con != null) con.disconnect();
        }
        return r;
    }

    /**
     * A rede da trava não tem internet; se os dados móveis estiverem ligados, o Android
     * tende a mandar o tráfego pelo 4G. Por isso a conexão é aberta direto pelo Wi-Fi.
     */
    @SuppressWarnings("deprecation")
    private HttpURLConnection abrirConexao(URL url) throws IOException {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    return (HttpURLConnection) n.openConnection(url);
                }
            }
        }
        return (HttpURLConnection) url.openConnection();
    }

    private static String lerTudo(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] b = new byte[1024];
        int n;
        while ((n = in.read(b)) > 0) buf.write(b, 0, n);
        in.close();
        return buf.toString("UTF-8");
    }

    private static String codificar(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    // ------------------------------------------------------------------ utilidades

    private String ip() {
        return prefs.getString("ip", IP_PADRAO);
    }

    private String pin() {
        return prefs.getString("pin", "");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
